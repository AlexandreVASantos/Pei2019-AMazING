#!/bin/bash

sudo python3 /home/amazing/dont_delete/node_init.py &
